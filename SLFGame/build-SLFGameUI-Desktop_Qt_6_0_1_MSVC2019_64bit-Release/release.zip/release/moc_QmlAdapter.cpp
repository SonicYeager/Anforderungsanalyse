/****************************************************************************
** Meta object code from reading C++ file 'QmlAdapter.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.0.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../SLFGameUI/QmlAdapter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QmlAdapter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.0.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QmlAdapter_t {
    const uint offsetsAndSize[138];
    char stringdata0[914];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_QmlAdapter_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_QmlAdapter_t qt_meta_stringdata_QmlAdapter = {
    {
QT_MOC_LITERAL(0, 10), // "QmlAdapter"
QT_MOC_LITERAL(11, 13), // "letterChanged"
QT_MOC_LITERAL(25, 0), // ""
QT_MOC_LITERAL(26, 17), // "categoriesChanged"
QT_MOC_LITERAL(44, 23), // "customCategoriesChanged"
QT_MOC_LITERAL(68, 14), // "answersChanged"
QT_MOC_LITERAL(83, 20), // "categoryCountChanged"
QT_MOC_LITERAL(104, 21), // "customChecked_changed"
QT_MOC_LITERAL(126, 19), // "currentRoundChanged"
QT_MOC_LITERAL(146, 16), // "maxRoundsChanged"
QT_MOC_LITERAL(163, 13), // "pointsChanged"
QT_MOC_LITERAL(177, 15), // "timeLeftChanged"
QT_MOC_LITERAL(193, 16), // "lobbyCodeChanged"
QT_MOC_LITERAL(210, 18), // "playerCountChanged"
QT_MOC_LITERAL(229, 25), // "activeOverviewItemChanged"
QT_MOC_LITERAL(255, 16), // "decisionsChanged"
QT_MOC_LITERAL(272, 14), // "playersChanged"
QT_MOC_LITERAL(287, 11), // "viewChanged"
QT_MOC_LITERAL(299, 15), // "playerIdChanged"
QT_MOC_LITERAL(315, 17), // "playerNameChanged"
QT_MOC_LITERAL(333, 16), // "roundTimeChanged"
QT_MOC_LITERAL(350, 14), // "chatLogChanged"
QT_MOC_LITERAL(365, 14), // "answersRequest"
QT_MOC_LITERAL(380, 9), // "hostLobby"
QT_MOC_LITERAL(390, 9), // "joinLobby"
QT_MOC_LITERAL(400, 15), // "sendChatMessage"
QT_MOC_LITERAL(416, 3), // "str"
QT_MOC_LITERAL(420, 18), // "triggerStateChange"
QT_MOC_LITERAL(439, 11), // "sendAnswers"
QT_MOC_LITERAL(451, 20), // "lobbySettingsChanged"
QT_MOC_LITERAL(472, 15), // "getCategoryName"
QT_MOC_LITERAL(488, 3), // "idx"
QT_MOC_LITERAL(492, 9), // "getAnswer"
QT_MOC_LITERAL(502, 8), // "playerID"
QT_MOC_LITERAL(511, 11), // "categoryIDX"
QT_MOC_LITERAL(523, 9), // "getPlayer"
QT_MOC_LITERAL(533, 11), // "getDecision"
QT_MOC_LITERAL(545, 15), // "votingPlayerIDX"
QT_MOC_LITERAL(561, 15), // "setActiveItemIA"
QT_MOC_LITERAL(577, 11), // "setDecision"
QT_MOC_LITERAL(589, 6), // "newVal"
QT_MOC_LITERAL(596, 9), // "addAnswer"
QT_MOC_LITERAL(606, 6), // "answer"
QT_MOC_LITERAL(613, 25), // "triggerStateRelatedSignal"
QT_MOC_LITERAL(639, 5), // "STATE"
QT_MOC_LITERAL(645, 15), // "changeVoteState"
QT_MOC_LITERAL(661, 9), // "clearChat"
QT_MOC_LITERAL(671, 6), // "letter"
QT_MOC_LITERAL(678, 9), // "lobbyCode"
QT_MOC_LITERAL(688, 16), // "customCategories"
QT_MOC_LITERAL(705, 9), // "maxRounds"
QT_MOC_LITERAL(715, 9), // "roundTime"
QT_MOC_LITERAL(725, 8), // "timeLeft"
QT_MOC_LITERAL(734, 4), // "view"
QT_MOC_LITERAL(739, 10), // "playerName"
QT_MOC_LITERAL(750, 7), // "chatLog"
QT_MOC_LITERAL(758, 10), // "categories"
QT_MOC_LITERAL(769, 9), // "StrVector"
QT_MOC_LITERAL(779, 7), // "answers"
QT_MOC_LITERAL(787, 11), // "StrVector2D"
QT_MOC_LITERAL(799, 7), // "players"
QT_MOC_LITERAL(807, 18), // "QList<QVariantMap>"
QT_MOC_LITERAL(826, 13), // "categoryCount"
QT_MOC_LITERAL(840, 12), // "currentRound"
QT_MOC_LITERAL(853, 6), // "points"
QT_MOC_LITERAL(860, 18), // "activeOverviewItem"
QT_MOC_LITERAL(879, 11), // "playerCount"
QT_MOC_LITERAL(891, 8), // "playerId"
QT_MOC_LITERAL(900, 13) // "customChecked"

    },
    "QmlAdapter\0letterChanged\0\0categoriesChanged\0"
    "customCategoriesChanged\0answersChanged\0"
    "categoryCountChanged\0customChecked_changed\0"
    "currentRoundChanged\0maxRoundsChanged\0"
    "pointsChanged\0timeLeftChanged\0"
    "lobbyCodeChanged\0playerCountChanged\0"
    "activeOverviewItemChanged\0decisionsChanged\0"
    "playersChanged\0viewChanged\0playerIdChanged\0"
    "playerNameChanged\0roundTimeChanged\0"
    "chatLogChanged\0answersRequest\0hostLobby\0"
    "joinLobby\0sendChatMessage\0str\0"
    "triggerStateChange\0sendAnswers\0"
    "lobbySettingsChanged\0getCategoryName\0"
    "idx\0getAnswer\0playerID\0categoryIDX\0"
    "getPlayer\0getDecision\0votingPlayerIDX\0"
    "setActiveItemIA\0setDecision\0newVal\0"
    "addAnswer\0answer\0triggerStateRelatedSignal\0"
    "STATE\0changeVoteState\0clearChat\0letter\0"
    "lobbyCode\0customCategories\0maxRounds\0"
    "roundTime\0timeLeft\0view\0playerName\0"
    "chatLog\0categories\0StrVector\0answers\0"
    "StrVector2D\0players\0QList<QVariantMap>\0"
    "categoryCount\0currentRound\0points\0"
    "activeOverviewItem\0playerCount\0playerId\0"
    "customChecked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QmlAdapter[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
      19,  305, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      21,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  236,    2, 0x06,   19 /* Public */,
       3,    0,  237,    2, 0x06,   20 /* Public */,
       4,    0,  238,    2, 0x06,   21 /* Public */,
       5,    0,  239,    2, 0x06,   22 /* Public */,
       6,    0,  240,    2, 0x06,   23 /* Public */,
       7,    0,  241,    2, 0x06,   24 /* Public */,
       8,    0,  242,    2, 0x06,   25 /* Public */,
       9,    0,  243,    2, 0x06,   26 /* Public */,
      10,    0,  244,    2, 0x06,   27 /* Public */,
      11,    0,  245,    2, 0x06,   28 /* Public */,
      12,    0,  246,    2, 0x06,   29 /* Public */,
      13,    0,  247,    2, 0x06,   30 /* Public */,
      14,    0,  248,    2, 0x06,   31 /* Public */,
      15,    0,  249,    2, 0x06,   32 /* Public */,
      16,    0,  250,    2, 0x06,   33 /* Public */,
      17,    0,  251,    2, 0x06,   34 /* Public */,
      18,    0,  252,    2, 0x06,   35 /* Public */,
      19,    0,  253,    2, 0x06,   36 /* Public */,
      20,    0,  254,    2, 0x06,   37 /* Public */,
      21,    0,  255,    2, 0x06,   38 /* Public */,
      22,    0,  256,    2, 0x06,   39 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      23,    0,  257,    2, 0x0a,   40 /* Public */,
      24,    0,  258,    2, 0x0a,   41 /* Public */,
      25,    1,  259,    2, 0x0a,   42 /* Public */,
      27,    1,  262,    2, 0x0a,   44 /* Public */,
      28,    0,  265,    2, 0x0a,   46 /* Public */,
      29,    0,  266,    2, 0x0a,   47 /* Public */,
      30,    1,  267,    2, 0x0a,   48 /* Public */,
      32,    2,  270,    2, 0x0a,   50 /* Public */,
      35,    1,  275,    2, 0x0a,   53 /* Public */,
      36,    3,  278,    2, 0x0a,   55 /* Public */,
      38,    1,  285,    2, 0x0a,   59 /* Public */,
      39,    3,  288,    2, 0x0a,   61 /* Public */,
      41,    1,  295,    2, 0x0a,   65 /* Public */,
      43,    1,  298,    2, 0x0a,   67 /* Public */,
      45,    1,  301,    2, 0x0a,   69 /* Public */,
      46,    0,  304,    2, 0x0a,   71 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QString, QMetaType::Int,   31,
    QMetaType::QString, QMetaType::Int, QMetaType::Int,   33,   34,
    QMetaType::QString, QMetaType::Int,   31,
    QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Int,   33,   34,   37,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   33,   34,   40,
    QMetaType::Void, QMetaType::QString,   42,
    QMetaType::Void, 0x80000000 | 44,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,

 // properties: name, type, flags
      47, QMetaType::QString, 0x00015103, uint(0), 0,
      48, QMetaType::QString, 0x00015103, uint(10), 0,
      49, QMetaType::QString, 0x00015103, uint(2), 0,
      50, QMetaType::QString, 0x00015103, uint(7), 0,
      51, QMetaType::QString, 0x00015103, uint(18), 0,
      52, QMetaType::QString, 0x00015103, uint(9), 0,
      53, QMetaType::QString, 0x00015103, uint(15), 0,
      54, QMetaType::QString, 0x00015103, uint(17), 0,
      55, QMetaType::QString, 0x00015001, uint(19), 0,
      56, 0x80000000 | 57, 0x0001510b, uint(1), 0,
      58, 0x80000000 | 59, 0x0001510b, uint(3), 0,
      60, 0x80000000 | 61, 0x0001510b, uint(14), 0,
      62, QMetaType::Int, 0x00015103, uint(4), 0,
      63, QMetaType::Int, 0x00015103, uint(6), 0,
      64, QMetaType::Int, 0x00015103, uint(8), 0,
      65, QMetaType::Int, 0x00015103, uint(12), 0,
      66, QMetaType::Int, 0x00015103, uint(11), 0,
      67, QMetaType::Int, 0x00015103, uint(16), 0,
      68, QMetaType::Bool, 0x00015003, uint(5), 0,

       0        // eod
};

void QmlAdapter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QmlAdapter *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->letterChanged(); break;
        case 1: _t->categoriesChanged(); break;
        case 2: _t->customCategoriesChanged(); break;
        case 3: _t->answersChanged(); break;
        case 4: _t->categoryCountChanged(); break;
        case 5: _t->customChecked_changed(); break;
        case 6: _t->currentRoundChanged(); break;
        case 7: _t->maxRoundsChanged(); break;
        case 8: _t->pointsChanged(); break;
        case 9: _t->timeLeftChanged(); break;
        case 10: _t->lobbyCodeChanged(); break;
        case 11: _t->playerCountChanged(); break;
        case 12: _t->activeOverviewItemChanged(); break;
        case 13: _t->decisionsChanged(); break;
        case 14: _t->playersChanged(); break;
        case 15: _t->viewChanged(); break;
        case 16: _t->playerIdChanged(); break;
        case 17: _t->playerNameChanged(); break;
        case 18: _t->roundTimeChanged(); break;
        case 19: _t->chatLogChanged(); break;
        case 20: _t->answersRequest(); break;
        case 21: _t->hostLobby(); break;
        case 22: _t->joinLobby(); break;
        case 23: _t->sendChatMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->triggerStateChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->sendAnswers(); break;
        case 26: _t->lobbySettingsChanged(); break;
        case 27: { QString _r = _t->getCategoryName((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 28: { QString _r = _t->getAnswer((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 29: { QString _r = _t->getPlayer((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 30: { bool _r = _t->getDecision((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 31: _t->setActiveItemIA((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 32: _t->setDecision((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 33: _t->addAnswer((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 34: _t->triggerStateRelatedSignal((*reinterpret_cast< STATE(*)>(_a[1]))); break;
        case 35: _t->changeVoteState((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->clearChat(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::letterChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::categoriesChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::customCategoriesChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::answersChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::categoryCountChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::customChecked_changed)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::currentRoundChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::maxRoundsChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::pointsChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::timeLeftChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::lobbyCodeChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::playerCountChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::activeOverviewItemChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::decisionsChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::playersChanged)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::viewChanged)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::playerIdChanged)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::playerNameChanged)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::roundTimeChanged)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::chatLogChanged)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::answersRequest)) {
                *result = 20;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 11:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QVariantMap> >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QmlAdapter *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->getLetter(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->getLobbyCode(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->getCustomCategories(); break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->getMaxRounds(); break;
        case 4: *reinterpret_cast< QString*>(_v) = _t->getRoundTime(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->getTimeLeft(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->getView(); break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->getPlayerName(); break;
        case 8: *reinterpret_cast< QString*>(_v) = _t->getChatLog(); break;
        case 9: *reinterpret_cast< StrVector*>(_v) = _t->getCategories(); break;
        case 10: *reinterpret_cast< StrVector2D*>(_v) = _t->getAnswers(); break;
        case 11: *reinterpret_cast< QList<QVariantMap>*>(_v) = _t->getPlayers(); break;
        case 12: *reinterpret_cast< int*>(_v) = _t->getCategoryCount(); break;
        case 13: *reinterpret_cast< int*>(_v) = _t->getCurrentRound(); break;
        case 14: *reinterpret_cast< int*>(_v) = _t->getPoints(); break;
        case 15: *reinterpret_cast< int*>(_v) = _t->getActiveOverviewItem(); break;
        case 16: *reinterpret_cast< int*>(_v) = _t->getPlayerCount(); break;
        case 17: *reinterpret_cast< int*>(_v) = _t->getPlayerId(); break;
        case 18: *reinterpret_cast< bool*>(_v) = _t->get_customChecked(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QmlAdapter *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setLetter(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setLobbyCode(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setCustomCategories(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setMaxRounds(*reinterpret_cast< QString*>(_v)); break;
        case 4: _t->setRoundTime(*reinterpret_cast< QString*>(_v)); break;
        case 5: _t->setTimeLeft(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setView(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setPlayerName(*reinterpret_cast< QString*>(_v)); break;
        case 9: _t->setCategories(*reinterpret_cast< StrVector*>(_v)); break;
        case 10: _t->setAnswers(*reinterpret_cast< StrVector2D*>(_v)); break;
        case 11: _t->setPlayers(*reinterpret_cast< QList<QVariantMap>*>(_v)); break;
        case 12: _t->setCategoryCount(*reinterpret_cast< int*>(_v)); break;
        case 13: _t->setCurrentRound(*reinterpret_cast< int*>(_v)); break;
        case 14: _t->setPoints(*reinterpret_cast< int*>(_v)); break;
        case 15: _t->setActiveOverviewItem(*reinterpret_cast< int*>(_v)); break;
        case 16: _t->setPlayerCount(*reinterpret_cast< int*>(_v)); break;
        case 17: _t->setPlayerId(*reinterpret_cast< int*>(_v)); break;
        case 18: _t->set_customChecked(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QmlAdapter::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_QmlAdapter.offsetsAndSize,
    qt_meta_data_QmlAdapter,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_QmlAdapter_t
, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<StrVector, std::true_type>, QtPrivate::TypeAndForceComplete<StrVector2D, std::true_type>, QtPrivate::TypeAndForceComplete<QList<QVariantMap>, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<bool, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<STATE, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *QmlAdapter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QmlAdapter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QmlAdapter.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "UI"))
        return static_cast< UI*>(this);
    return QObject::qt_metacast(_clname);
}

int QmlAdapter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 37;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QmlAdapter::letterChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QmlAdapter::categoriesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QmlAdapter::customCategoriesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QmlAdapter::answersChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QmlAdapter::categoryCountChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QmlAdapter::customChecked_changed()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QmlAdapter::currentRoundChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void QmlAdapter::maxRoundsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QmlAdapter::pointsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QmlAdapter::timeLeftChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QmlAdapter::lobbyCodeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QmlAdapter::playerCountChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QmlAdapter::activeOverviewItemChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void QmlAdapter::decisionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void QmlAdapter::playersChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void QmlAdapter::viewChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void QmlAdapter::playerIdChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}

// SIGNAL 17
void QmlAdapter::playerNameChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void QmlAdapter::roundTimeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}

// SIGNAL 19
void QmlAdapter::chatLogChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 19, nullptr);
}

// SIGNAL 20
void QmlAdapter::answersRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 20, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
