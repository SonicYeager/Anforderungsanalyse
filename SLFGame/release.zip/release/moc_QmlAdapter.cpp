/****************************************************************************
** Meta object code from reading C++ file 'QmlAdapter.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.0.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../SLFGameUI/QmlAdapter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QmlAdapter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.0.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QmlAdapter_t {
    const uint offsetsAndSize[90];
    char stringdata0[662];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_QmlAdapter_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_QmlAdapter_t qt_meta_stringdata_QmlAdapter = {
    {
QT_MOC_LITERAL(0, 10), // "QmlAdapter"
QT_MOC_LITERAL(11, 13), // "letterChanged"
QT_MOC_LITERAL(25, 0), // ""
QT_MOC_LITERAL(26, 17), // "categoriesChanged"
QT_MOC_LITERAL(44, 23), // "customCategoriesChanged"
QT_MOC_LITERAL(68, 14), // "answersChanged"
QT_MOC_LITERAL(83, 20), // "categoryCountChanged"
QT_MOC_LITERAL(104, 20), // "customCheckedChanged"
QT_MOC_LITERAL(125, 25), // "lobbyScreenVisibleChanged"
QT_MOC_LITERAL(151, 25), // "entryScreenVisibleChanged"
QT_MOC_LITERAL(177, 28), // "overviewScreenVisibleChanged"
QT_MOC_LITERAL(206, 19), // "currentRoundChanged"
QT_MOC_LITERAL(226, 16), // "maxRoundsChanged"
QT_MOC_LITERAL(243, 13), // "pointsChanged"
QT_MOC_LITERAL(257, 15), // "timeLeftChanged"
QT_MOC_LITERAL(273, 16), // "lobbyCodeChanged"
QT_MOC_LITERAL(290, 18), // "playerCountChanged"
QT_MOC_LITERAL(309, 25), // "activeOverviewItemChanged"
QT_MOC_LITERAL(335, 15), // "getCategoryName"
QT_MOC_LITERAL(351, 3), // "idx"
QT_MOC_LITERAL(355, 9), // "getAnswer"
QT_MOC_LITERAL(365, 11), // "getDecision"
QT_MOC_LITERAL(377, 11), // "setDecision"
QT_MOC_LITERAL(389, 6), // "newVal"
QT_MOC_LITERAL(396, 11), // "prepareGame"
QT_MOC_LITERAL(408, 15), // "prepareOverview"
QT_MOC_LITERAL(424, 9), // "addAnswer"
QT_MOC_LITERAL(434, 6), // "answer"
QT_MOC_LITERAL(441, 6), // "letter"
QT_MOC_LITERAL(448, 9), // "lobbyCode"
QT_MOC_LITERAL(458, 16), // "customCategories"
QT_MOC_LITERAL(475, 9), // "maxRounds"
QT_MOC_LITERAL(485, 8), // "timeLeft"
QT_MOC_LITERAL(494, 10), // "categories"
QT_MOC_LITERAL(505, 9), // "StrVector"
QT_MOC_LITERAL(515, 7), // "answers"
QT_MOC_LITERAL(523, 13), // "categoryCount"
QT_MOC_LITERAL(537, 12), // "currentRound"
QT_MOC_LITERAL(550, 6), // "points"
QT_MOC_LITERAL(557, 18), // "activeOverviewItem"
QT_MOC_LITERAL(576, 11), // "playerCount"
QT_MOC_LITERAL(588, 13), // "customChecked"
QT_MOC_LITERAL(602, 18), // "lobbyScreenVisible"
QT_MOC_LITERAL(621, 18), // "entryScreenVisible"
QT_MOC_LITERAL(640, 21) // "overviewScreenVisible"

    },
    "QmlAdapter\0letterChanged\0\0categoriesChanged\0"
    "customCategoriesChanged\0answersChanged\0"
    "categoryCountChanged\0customCheckedChanged\0"
    "lobbyScreenVisibleChanged\0"
    "entryScreenVisibleChanged\0"
    "overviewScreenVisibleChanged\0"
    "currentRoundChanged\0maxRoundsChanged\0"
    "pointsChanged\0timeLeftChanged\0"
    "lobbyCodeChanged\0playerCountChanged\0"
    "activeOverviewItemChanged\0getCategoryName\0"
    "idx\0getAnswer\0getDecision\0setDecision\0"
    "newVal\0prepareGame\0prepareOverview\0"
    "addAnswer\0answer\0letter\0lobbyCode\0"
    "customCategories\0maxRounds\0timeLeft\0"
    "categories\0StrVector\0answers\0categoryCount\0"
    "currentRound\0points\0activeOverviewItem\0"
    "playerCount\0customChecked\0lobbyScreenVisible\0"
    "entryScreenVisible\0overviewScreenVisible"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QmlAdapter[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
      16,  187, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      16,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  152,    2, 0x06,   16 /* Public */,
       3,    0,  153,    2, 0x06,   17 /* Public */,
       4,    0,  154,    2, 0x06,   18 /* Public */,
       5,    0,  155,    2, 0x06,   19 /* Public */,
       6,    0,  156,    2, 0x06,   20 /* Public */,
       7,    0,  157,    2, 0x06,   21 /* Public */,
       8,    0,  158,    2, 0x06,   22 /* Public */,
       9,    0,  159,    2, 0x06,   23 /* Public */,
      10,    0,  160,    2, 0x06,   24 /* Public */,
      11,    0,  161,    2, 0x06,   25 /* Public */,
      12,    0,  162,    2, 0x06,   26 /* Public */,
      13,    0,  163,    2, 0x06,   27 /* Public */,
      14,    0,  164,    2, 0x06,   28 /* Public */,
      15,    0,  165,    2, 0x06,   29 /* Public */,
      16,    0,  166,    2, 0x06,   30 /* Public */,
      17,    0,  167,    2, 0x06,   31 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      18,    1,  168,    2, 0x0a,   32 /* Public */,
      20,    1,  171,    2, 0x0a,   34 /* Public */,
      21,    1,  174,    2, 0x0a,   36 /* Public */,
      22,    2,  177,    2, 0x0a,   38 /* Public */,
      24,    0,  182,    2, 0x0a,   41 /* Public */,
      25,    0,  183,    2, 0x0a,   42 /* Public */,
      26,    1,  184,    2, 0x0a,   43 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::QString, QMetaType::Int,   19,
    QMetaType::QString, QMetaType::Int,   19,
    QMetaType::Int, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   19,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   27,

 // properties: name, type, flags
      28, QMetaType::QString, 0x00015103, uint(0), 0,
      29, QMetaType::QString, 0x00015103, uint(13), 0,
      30, QMetaType::QString, 0x00015103, uint(2), 0,
      31, QMetaType::QString, 0x00015103, uint(10), 0,
      32, QMetaType::QString, 0x00015103, uint(12), 0,
      33, 0x80000000 | 34, 0x0001510b, uint(1), 0,
      35, 0x80000000 | 34, 0x0001510b, uint(3), 0,
      36, QMetaType::Int, 0x00015103, uint(4), 0,
      37, QMetaType::Int, 0x00015103, uint(9), 0,
      38, QMetaType::Int, 0x00015103, uint(11), 0,
      39, QMetaType::Int, 0x00015103, uint(15), 0,
      40, QMetaType::Int, 0x00015103, uint(14), 0,
      41, QMetaType::Bool, 0x00015103, uint(5), 0,
      42, QMetaType::Bool, 0x00015103, uint(6), 0,
      43, QMetaType::Bool, 0x00015103, uint(7), 0,
      44, QMetaType::Bool, 0x00015103, uint(8), 0,

       0        // eod
};

void QmlAdapter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QmlAdapter *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->letterChanged(); break;
        case 1: _t->categoriesChanged(); break;
        case 2: _t->customCategoriesChanged(); break;
        case 3: _t->answersChanged(); break;
        case 4: _t->categoryCountChanged(); break;
        case 5: _t->customCheckedChanged(); break;
        case 6: _t->lobbyScreenVisibleChanged(); break;
        case 7: _t->entryScreenVisibleChanged(); break;
        case 8: _t->overviewScreenVisibleChanged(); break;
        case 9: _t->currentRoundChanged(); break;
        case 10: _t->maxRoundsChanged(); break;
        case 11: _t->pointsChanged(); break;
        case 12: _t->timeLeftChanged(); break;
        case 13: _t->lobbyCodeChanged(); break;
        case 14: _t->playerCountChanged(); break;
        case 15: _t->activeOverviewItemChanged(); break;
        case 16: { QString _r = _t->getCategoryName((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 17: { QString _r = _t->getAnswer((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 18: { int _r = _t->getDecision((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 19: _t->setDecision((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 20: _t->prepareGame(); break;
        case 21: _t->prepareOverview(); break;
        case 22: _t->addAnswer((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::letterChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::categoriesChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::customCategoriesChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::answersChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::categoryCountChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::customCheckedChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::lobbyScreenVisibleChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::entryScreenVisibleChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::overviewScreenVisibleChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::currentRoundChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::maxRoundsChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::pointsChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::timeLeftChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::lobbyCodeChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::playerCountChanged)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (QmlAdapter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAdapter::activeOverviewItemChanged)) {
                *result = 15;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QmlAdapter *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->getLetter(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->getLobbyCode(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->getCustomCategories(); break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->getMaxRounds(); break;
        case 4: *reinterpret_cast< QString*>(_v) = _t->getTimeLeft(); break;
        case 5: *reinterpret_cast< StrVector*>(_v) = _t->getCategories(); break;
        case 6: *reinterpret_cast< StrVector*>(_v) = _t->getAnswers(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->getCategoryCount(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->getCurrentRound(); break;
        case 9: *reinterpret_cast< int*>(_v) = _t->getPoints(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->getActiveOverviewItem(); break;
        case 11: *reinterpret_cast< int*>(_v) = _t->getPlayerCount(); break;
        case 12: *reinterpret_cast< bool*>(_v) = _t->getCustomChecked(); break;
        case 13: *reinterpret_cast< bool*>(_v) = _t->getLobbyScreenVisible(); break;
        case 14: *reinterpret_cast< bool*>(_v) = _t->getEntryScreenVisible(); break;
        case 15: *reinterpret_cast< bool*>(_v) = _t->getOverviewScreenVisible(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QmlAdapter *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setLetter(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setLobbyCode(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setCustomCategories(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setMaxRounds(*reinterpret_cast< QString*>(_v)); break;
        case 4: _t->setTimeLeft(*reinterpret_cast< QString*>(_v)); break;
        case 5: _t->setCategories(*reinterpret_cast< StrVector*>(_v)); break;
        case 6: _t->setAnswers(*reinterpret_cast< StrVector*>(_v)); break;
        case 7: _t->setCategoryCount(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setCurrentRound(*reinterpret_cast< int*>(_v)); break;
        case 9: _t->setPoints(*reinterpret_cast< int*>(_v)); break;
        case 10: _t->setActiveOverviewItem(*reinterpret_cast< int*>(_v)); break;
        case 11: _t->setPlayerCount(*reinterpret_cast< int*>(_v)); break;
        case 12: _t->setCustomChecked(*reinterpret_cast< bool*>(_v)); break;
        case 13: _t->setLobbyScreenVisible(*reinterpret_cast< bool*>(_v)); break;
        case 14: _t->setEntryScreenVisible(*reinterpret_cast< bool*>(_v)); break;
        case 15: _t->setOverviewScreenVisible(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QmlAdapter::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_QmlAdapter.offsetsAndSize,
    qt_meta_data_QmlAdapter,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_QmlAdapter_t
, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<QString, std::true_type>, QtPrivate::TypeAndForceComplete<StrVector, std::true_type>, QtPrivate::TypeAndForceComplete<StrVector, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<int, std::true_type>, QtPrivate::TypeAndForceComplete<bool, std::true_type>, QtPrivate::TypeAndForceComplete<bool, std::true_type>, QtPrivate::TypeAndForceComplete<bool, std::true_type>, QtPrivate::TypeAndForceComplete<bool, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>


>,
    nullptr
} };


const QMetaObject *QmlAdapter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QmlAdapter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QmlAdapter.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "UI"))
        return static_cast< UI*>(this);
    return QObject::qt_metacast(_clname);
}

int QmlAdapter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QmlAdapter::letterChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QmlAdapter::categoriesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QmlAdapter::customCategoriesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QmlAdapter::answersChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QmlAdapter::categoryCountChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QmlAdapter::customCheckedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QmlAdapter::lobbyScreenVisibleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void QmlAdapter::entryScreenVisibleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QmlAdapter::overviewScreenVisibleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QmlAdapter::currentRoundChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QmlAdapter::maxRoundsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QmlAdapter::pointsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QmlAdapter::timeLeftChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void QmlAdapter::lobbyCodeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void QmlAdapter::playerCountChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void QmlAdapter::activeOverviewItemChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
